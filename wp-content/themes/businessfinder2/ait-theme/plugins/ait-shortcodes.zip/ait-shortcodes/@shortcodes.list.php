<?php

/*
 * AIT Shortcodes WordPress Plugin
 *
 * Copyright (c) 2013, Affinity Information Technology, s.r.o. (http://ait-themes.com)
 */

return array(
	'button'        => true,
	'lists'         => true,
	'notification'  => true,
	'raw'           => true,
	'rule'          => true,
	'modal-link'    => true,
	'modal-content' => true,
);